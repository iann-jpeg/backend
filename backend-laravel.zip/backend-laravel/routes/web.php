<?php

// kept for compatibility; routes are defined in bootstrap/app.php for this minimal scaffold

